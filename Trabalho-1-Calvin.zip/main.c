#include <stdio.h>

int main (void){

//Eu printei cada linha com um printf diferente, coloquei \ antes das aspas e coloquei quebra de linha.

  printf ("                                o$o\n");
  printf ("                                $  \"o        o$o\n");
  printf ("                 o              $    \"o     o\" \"o   o\n");
  printf ("                 \"$$\"\"\"ooooo    $      \"o  o\"   \"o $ $  $\n");
  printf ("                   \"$oo    \"\"$o $        \"o\"     \"o\" \"o $      oo\n");
  printf ("                      \"\"\"oo   \"\"$o        \"\"      \"   \"o$o oo\"\"  $\n");
  printf ("                          \"$oo   \"                   $\"\" \"\"   ooo$\n");
  printf ("                  ooooooooo    oooooo\"\"\"\"           $   o       \"\"\"\"oo\n");
  printf ("         \"\"\"\"\"\"\"\"\"        \"\"                        $   $$  $  \"ooo  $\n");
  printf ("                 o                          \"\"\"oo  $   o\" $o\"$   $ \"\"\n");
  printf ("         oooooo$\"$\"\"\"\"\"\"                    ooo   o\"   $     \"ooo\"\n");
  printf ("                 $                             \" o$   $\n");
  printf ("                 $                         ooo$$$$\"  o\"\"\"o\n");
  printf ("                 $          ooooooo  ooo$$$\"\"\"o$\"$   $   $\n");
  printf ("                 \"o      oo$\"ooooo$$$\"\"\"   oooo o\"  o\"   $\n");
  printf ("                 o$o\"\"\"$o$$$\"\"\"$$$$$      o\"   \"\"\"\"\"$oo$\"\n");
  printf ("                $oo$$$\"$$\"$$   $$$$$      $oo           \"$\"\n");
  printf ("                $$$$$  $$o$$$$$$$$\"      $   \"\"\"\"oooo   o\"\n");
  printf ("                 $$$$$$$\"   \"\"\"\"\"  oo    $o          \"\"$\n");
  printf ("                  \"$\"\" $            $   $  \"\"\"oo      $\n");
  printf ("                   $   \"\"ooo\"\"     o\"  o\"\"oo    \"\"\"oo\"\n");
  printf ("                   $            oo\"    $    \"\"\"oo  o\"\n");
  printf ("         oooooo    $       \"\"\"\"\"      \"\"oo       $\"\n");
  printf ("     o\"\"\"     \"\"o   $oo       ooooo\"\"\"    \"\"\"oo  $\n");
  printf ("     $oo\"\" o\"   \"o     \"$$$\"\"\"     \"\"\"ooo      $\"\n");
  printf ("     o\"   $   $  \"o   o\"o  \"\"\"oooo       \"\"oo  $\n");
  printf ("     $   $$  o\"o  \"o $ $          \"\"\"ooo     \"$\n");
  printf ("      \"\"\"  \"\"  $    \"\"o$                \"\"\"\"oo\"\n");
  printf ("                $   o $\"\"\"\"\"\"\"\"\"\"\"ooooooo    $\n");
  printf ("                 \"o\" o\"                 \"\"$o$\n");
  printf ("                     $\"\"\"\"\"\"\"\"\"\"$oooo       $\n");
  printf ("                     $              \"\"\"$oo  $\n");
  printf ("                     $\"\"\"\"\"\"\"oooooooooo  \"\"\"$\n");
  printf ("                     $                 \"\"\"oo$\n");
  printf ("                     $\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"oooo  $\n");
  printf ("                      $   oooooooooooo    \"o $\n");
  printf ("                      $\"\"\"oooooooooooo\"\"\"\"oo$$oo\n");
  printf ("                       o$$$$$$$$$$$$$$$$$$o$$$$$o$\"\"$o\n");
  printf ("                       $$$$$$$$$$$$$$$$$$$$$$$$$$o   $\n");
  printf ("                        \"$$$$$$$$$$$$$$$$$$$$$$\" o\"  $\n");
  printf ("                           \"$$$$$$$$$$$$$$$$$$\"o\"  o$\n");
  printf ("                            $\"ooooo\"\"\"$\"oooooo\"   \"\"\n");
  printf ("                             $       $          $\n");
  printf ("                              $o      $o      o\"\n");
  printf ("               $$$$$$$$$$$$$$$$\"$ooo$\"\" \"ooo\"\"$$$$$$$$$$$$$$$$$$$$$$$$$$\"         Fonte: http://bit.ly/2W7Udd7\n");

return 0;


}