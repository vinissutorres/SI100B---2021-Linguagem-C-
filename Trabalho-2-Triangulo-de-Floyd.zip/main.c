/*COMENTARIOS

a variavel linhas é a entrada, o pcontador e scontador
significam respectivamente primeiro e segundo contador e 
eles são usados no for. na linha 36 e 37, tem dois fors 
aninhados, o primeiro for precisa estar presente porque se
nao varios zeros serão impressos, o segundo for faz com 
que as linhas pares apareçam corretamente. ex: na linha 4,
4 zeros vao aparecer, caso ele não existisse, só um zero 
seria impresso

na linha 38 e 41 tem um if e else que definem que nas 
linhas pares, 1 sera impresso e que na linha par, 0 sera impresso

o segundo if e else (linhas 46 e 48) define que nas linhas
pares nao vai aparecer o resultado da soma e que uma linha
sera pulada e que nas linhas impares, aparecerá o resultado 
da soma e acontecerá o pulo de uma linha

por fim, acontece a soma, que esta dentro do do-while (ou
seja, o que esta dentro do do vai acontecer enquanto a 
condição dentro do while for verdadeira) em que a variavel
fim soma a variavel linhas (entrada) e depois acontece o 
pos incremento, por ultimo acontece a impressao do 
resultado atraves da variavel fim*/

#include <stdio.h>

int main(void){

    int linhas; /*entrada*/
    int pcontador, scontador; /*contadores for*/
    int fim = 0; /*soma*/

    scanf("%i", &linhas);
    for(pcontador = 1; pcontador <= linhas; pcontador++){
      for(scontador = 1; scontador <= pcontador; scontador++){
            if(pcontador %2 == 1)
                printf("1");

            else
                printf("0"); 

       }

      if (pcontador %2 == 0)
        printf ("\n");
      else
        printf ("=%i\n", linhas);

  }

    do{
      fim = fim + linhas--;
    } while (linhas >= 1);

    printf ("%i\n", fim);

    return 0;

}