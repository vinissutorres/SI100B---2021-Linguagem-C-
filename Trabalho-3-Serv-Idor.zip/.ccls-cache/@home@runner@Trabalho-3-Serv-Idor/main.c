/*Neste trabalho, você deverá construir um programa que  receberá como parâmetro de 
entrada um número inteiro N, correspondente  ao tamanho da matriz de mapeamento 
(sempre quadrada), o fator de correção X (número inteiro), que deverá multiplicar 
todos os elementos da matriz original, a matriz original e, por fim, as posições que 
deverão ser percorridas na matriz para obtenção dos valores corretos de cada uma das 
regiões (colunas). Seu programa deve apresentar como saída a matriz corrigida, a soma, 
a média aritmética e o desvio padrão dos valores de cada uma das regiões (colunas)*/

#include <stdio.h>
#include <math.h> /*biblioteca utilizada para fazer algumas operacoes*/
#define LIM 10 /*limite maximo estipulado pelo exercicio*/

int main (void){

  int dimensoes, multiplicacao; //N e X, respectivamente
  float soma [LIM]; //float pois o exercicio quer saida com 2 zeros depois da virgula
  float plus[LIM]; //plus eh armazenado em soma depois
  float media [LIM]; //float por ser valor quebrado
  float auxiliar; //guarda por um tempo os valores da soma, usado pra fazer a media
  float desvio [LIM]; //float por ser valor quebrado
  float potenciacao; //guarda o que foi calculado no pow
  int temp; //temporario
  int matriz[LIM][LIM], fim[LIM][LIM]; //primeira matriz e matriz de saida
  int correcao[LIM][LIM]; //segunda matriz
  int contadorlinha, contadorcoluna; //for

  scanf ("%i", &dimensoes); //define tamanho da matriz
  scanf ("%i", &multiplicacao); /*valor que os elementos da matriz serao
  multiplicados, corrigindo ela*/

  /*os fors eu construi me baseando nos slides passados em aula,
  tentei colocar <= dimensoes, porem dava problema*/

  /*preenchimento da matriz original*/
  for (contadorlinha = 0; contadorlinha < dimensoes; contadorlinha++){
    for (contadorcoluna = 0; contadorcoluna < dimensoes; contadorcoluna++){
      scanf ("%i", &matriz[contadorlinha][contadorcoluna]);
    }
  }

  /*preenchimento da "matriz" que vai corrigir a posiçao dos valores*/
  for (contadorlinha = 0; contadorlinha < dimensoes; contadorlinha++){
    for (contadorcoluna = 0; contadorcoluna < dimensoes; contadorcoluna++){
        scanf ("%i", &correcao[contadorlinha][contadorcoluna]);
    }
  }
  
  /*aqui acontece a transposicao da matriz correcao  na linha 52 (inverti os contadores 
  das linhas e colunas), que é a segunda matriz,  a que corrige a posiçao dos valores da 
  primeira, eu coloquei o correcao numa variavel temporaria e depois atribui a minha matriz fim a matriz original porem com o segundo vetor substituido por temp*/
  for (contadorlinha = 0; contadorlinha < dimensoes; contadorlinha++){
    for (contadorcoluna = 0; contadorcoluna < dimensoes; contadorcoluna++){
        temp = correcao[contadorcoluna][contadorlinha];
        fim [contadorlinha][contadorcoluna] = matriz[contadorlinha][temp];
    }
  }

  /*multiplicacao, corrigindo os valores, eh necessario que fique no
  laço para que todos os valores sejam multiplicados*/
  for (contadorlinha = 0; contadorlinha < dimensoes; contadorlinha++){
    for (contadorcoluna = 0; contadorcoluna < dimensoes; contadorcoluna++){
       fim[contadorlinha][contadorcoluna] = fim[contadorlinha][contadorcoluna] * multiplicacao;
    }
  }

  /*impressao da matriz corrigida e multiplicada, eh necessario ficar no laço pra que
  todos os valores sejam impressos*/
  printf ("Matriz corrigida\n");
  for (contadorlinha = 0; contadorlinha < dimensoes; contadorlinha++){
    for (contadorcoluna = 0; contadorcoluna < dimensoes; contadorcoluna++){
        printf ("%i\t", fim[contadorlinha][contadorcoluna]);
    }
    printf ("\n"); /*a quebra de linha deve estar fora do segundo laço pra que a saida 
    tenha o formato de matriz*/
  }

  /*aqui acontece a soma das colunas da matriz fim, aqui os fors sao invertidos
  para que a coluna seja lida primeiro, afinal o exercicio quer a soma das colunas,
  antes eu tinha colocado a soma sem ser um vetor, nao estava funcionando, pois
  imprimia lixo, dai coloquei plus (soma) como um vetor*/
  for (contadorcoluna = 0; contadorcoluna < dimensoes; contadorcoluna++){
    for (contadorlinha = 0; contadorlinha < dimensoes; contadorlinha++){
        plus[contadorcoluna] = fim[contadorlinha][contadorcoluna] + plus[contadorcoluna];
    }
    soma[contadorcoluna] = plus[contadorcoluna];
  }

  /*aqui acontece o calculo da media das colunas da matriz fim, aqui os fors sao
  invertidos para que a coluna seja lida primeiro, coloquei a soma numa variavel
  auxiliar e dividi por dimensoes (que equivale ao numero de colunas e linhas na
  parte de cima do programa)*/
  for (contadorcoluna = 0; contadorcoluna < dimensoes; contadorcoluna++){
    for (contadorlinha = 0; contadorlinha < dimensoes; contadorlinha++){
        auxiliar = soma[contadorcoluna];
        media[contadorcoluna] = soma[contadorcoluna] / dimensoes;
    }
  }
  
  /*aqui acontece o calculo do desvio padrao, eu tinha feito desse jeito abaixo 
  (comentado) e nao estava funcionando, dai pedi ajuda aos monitores, que me
  aconselharam em dividir o calculo do desvio em dois e usar o comando pow 
  (que consiste em base e expoente). primeiramente, fiz a potenciacao e
  dividi o valor pelas dimensoes (que equivale tanto ao numero de colunas e
  linhas da matriz) da matriz e tudo isso dentro da raiz quadrada
  for (contadorcoluna = 0; contadorcoluna < dimensoes; contadorcoluna++){
    for (contadorlinha = 0; contadorlinha < dimensoes; contadorlinha++){
        desvio[contadorcoluna] = sqrt (((fim[contadorlinha][contadorcoluna]) - media[contadorcoluna]) * (fim[contadorlinha][contadorcoluna] - media[contadorcoluna])) / dimensoes;
    }}*/

  for (contadorcoluna = 0; contadorcoluna < dimensoes; contadorcoluna++){
    for (contadorlinha = 0; contadorlinha < dimensoes; contadorlinha++){
      potenciacao = pow (fim[contadorlinha][contadorcoluna] - media[contadorcoluna], 2) + potenciacao;
    }
    desvio[contadorcoluna] = sqrt (potenciacao / dimensoes); 
    potenciacao = 0; /*importante colocar pra evitar problemas envolvendo uso
    dos resultados dos desvios anteriores*/
  }

  /*aqui eu nao coloquei o segundo for porque nao estava imprimindo apenas os
  3 valores e sim 9 valores*/
  printf ("Somas::");
  for (contadorcoluna = 0; contadorcoluna < dimensoes; contadorcoluna++){
    printf ("%.2f\t", soma[contadorcoluna]);
  }

  printf ("\n"); /*usado para as somas, medias e desvios nao ficarem colados
  na mesma linha*/

  /*aqui eu nao coloquei o segundo for porque nao estava imprimindo apenas os
  3 valores e sim 9 valores*/
  printf ("Medias::");
  for (contadorcoluna = 0; contadorcoluna < dimensoes; contadorcoluna++){
    printf ("%.2f\t", media[contadorcoluna]);
  }

  printf ("\n"); /*usado para as somas, medias e desvios nao ficarem colados
  na mesma linha*/

  /*aqui eu nao coloquei o segundo for porque nao estava imprimindo apenas os
  3 valores e sim 9 valores*/
  printf ("Desvios::");
  for (contadorcoluna = 0; contadorcoluna < dimensoes; contadorcoluna++){
    printf ("%.2f\t", desvio[contadorcoluna]);
  }

  printf ("\n"); 

  return 0;

}