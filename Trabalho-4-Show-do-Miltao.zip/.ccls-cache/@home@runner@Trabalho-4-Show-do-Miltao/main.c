/*você deverá construir um programa que lerá uma sequência de dados 
referentes a cada pergunta: o tipo da pergunta, que será INT para 
respostas com números inteiros e FLOAT para respostas com números 
em ponto flutuante, a pergunta, uma string de no máximo 100 
caracteres, três alternativas, que podem ser tanto números inteiros 
ou pontos flutuantes, e a resposta correta, um número inteiro 
indicando qual das alternativas é a correta (0, 1 ou 2) para aquela 
pergunta. Essas perguntas devem ser cadastradas no sistema até que 
a palavra "FIM" seja digitada.Depois de cadastradas as perguntas, 
seu programa está pronto para ser usado pela clientela de Miltão. 
Seu programa deve permitir que o usuário digite o tipo de pergunta 
desejada, INT para perguntas com respostas de números inteiros e 
FLOAT para perguntas que envolvem números de ponto flutuante, e o 
número da pergunta que o usuário deseja responder, de acordo com a 
a ordem em que foram cadastradas . Isso quer dizer que se o usuário 
digitar INT e 3, seu programa deve apresentar a terceira questão 
cadastrada do tipo inteiro. Seu programa deve continuar executando 
até que o usuário erre alguma questão ou que digite "FIM" novamente 
para sair do programa.A saída do seu programa deverá apresentar
uma única vez a frase "Prepare-se para o Show do Miltao!". Depois, 
deve apresentar a pergunta, as alternativas e se o usuário acertou 
ou errou a resposta. Para respostas com ponto flutuante 
apresentá-las com duas casas decimais*/

#include <stdio.h>
#include <string.h> //usada pra manipular strings, no caso as perguntas e os tipos de pergunta

int main (void){
  
  //variaveis globais/
  char tipopergunta[20]; //primeira vez pra digitar o tipo da pergunta (int/float)
  int auxI = 0; //ele funciona pra gravar a posicao do vetor das perguntas tipo int, deve comecar com 0 para nao ter lixo
  int auxF = 0; //ele funciona pra gravar a posicao do vetor das perguntas tipo float, deve começar com 0 pra nao ter lixo
  char CH = 0; //a pad disse que seria necessario declarar essa variavel quando usamos while ((CH = getchar()) != '\n');

  //usei structs porque elas servem para agrupar dados de tipos diferentes, assim como fizemos nos labs da semana de registros, eh possivel tambem fazer sem struct, mas acredito que seja mais dificil porque ficaria mais bagunçado/
  struct perguntasint {

    //variaveis locais/
    char pergunta[101]; //100 caracteres + 1, destinado pro \0;
    int alternativa1, alternativa2, alternativa3;
    int respostacorreta;
    int x; 

  } perguntasint[1000]; //nao renomeei, usei o mesmo nome, mas ai criei vetor

  //usei structs porque elas servem para agrupar dados de tipos diferentes/
  struct perguntasfloat {

    //variaveis locais/
    //observacao: variaveis em ingles se referem as variaveis do float/
    char question[201]; //200 caracteres + 1, destinado pro \0, inicialmente tinha colocado 101, mas dava problema no susy
    float options1, options2, options3; //alternativas
    int correctanswer; //resposta correta
    int x;

  } perguntasfloat[1000]; //nao renomeei, usei o mesmo nome, criei vetor com capacidade pra 1000 perguntas

  //usei do-while para repetir enquanto minha condicao na linha 92 for verdade
  do {
  
  scanf("%s", tipopergunta); //lendo tipo pergunta;

  //comparando a entrada
  if (strcmp(tipopergunta, "FLOAT") == 0){
    while ((CH = getchar()) != '\n'); //anteriormente, na semana dos labs de registro, a pad me disse que para tirar o \n, eu precisava usar esse comando, que funcionou
    fgets (perguntasfloat[auxF].question, 101, stdin); //lendo pergunta
    scanf ("%f", &perguntasfloat[auxF].options1); //lendo alternativa
    scanf ("%f", &perguntasfloat[auxF].options2); //lendo alternativa
    scanf ("%f", &perguntasfloat[auxF].options3); //lendo alternativa
    scanf ("%i", &perguntasfloat[auxF].correctanswer); //lendo respostacorreta
    perguntasfloat[auxF].question[strcspn(perguntasfloat[auxF].question, "\n")] = 0; //tirando \n do fgets
    perguntasfloat[auxF].x = auxF; //guardando num vetor
    auxF++; //cada vez que tudo isso dentro do if acontece, ha um incremento aqui
   
  }

      else if (strcmp(tipopergunta, "INT") == 0){
        while ((CH = getchar()) != '\n'); //tirando \n
        fgets (perguntasint[auxI].pergunta, 201, stdin);//lendo pergunta
        scanf ("%i", &perguntasint[auxI].alternativa1); //digitando alternativa
        scanf ("%i", &perguntasint[auxI].alternativa2); //digitando alternativa
        scanf ("%i", &perguntasint[auxI].alternativa3); //digitando alternativa
        scanf ("%i", &perguntasint[auxI].respostacorreta); //digitando a resposta correta
        perguntasint[auxI].pergunta[strcspn(perguntasint[auxI].pergunta, "\n")] = 0; //tirando \n do fgets
        perguntasint[auxI].x = auxI; //guardando no vetor
        auxI = auxI+1; //sofrendo incremento

      }
              else if (strcmp(tipopergunta, "FIM") == 0)
                break; //caso digitar fim, saira do programa

  } while (((strcmp(tipopergunta, "FIM") != 0))); //o cadastro de perguntas so para quando digita fim

  printf ("Prepare-se para o show do Miltao!\n");

  int numerocorrespondentedapergunta; //numero da pergunta 
  int respostadousuario; //resposta na pergunta int e float
  
  //tudo o que esta aqui dentro rodara enquanto a condiçao da linha 183 for verdade
  do {

   scanf("%s", tipopergunta);

    //comparando 
    if (strcmp(tipopergunta, "INT") == 0){
      scanf ("%i", &numerocorrespondentedapergunta); //lendo numero da pergunta
      printf ("Pergunta: %s", perguntasint[numerocorrespondentedapergunta].pergunta); //printando pergunta
      printf ("Alternativa 0: %i\n", perguntasint[numerocorrespondentedapergunta].alternativa1);
      printf ("Alternativa 1: %i\n", perguntasint[numerocorrespondentedapergunta].alternativa2);
      printf ("Alternativa 2: %i\n", perguntasint[numerocorrespondentedapergunta].alternativa3);
      scanf ("%i", &respostadousuario); //usuario digita sua resposta

      //verificando a resposta do usuario com a resposta cadastrada
      if (perguntasint[numerocorrespondentedapergunta].respostacorreta == respostadousuario){
        printf ("Parabens, voce acertou!\n");

        if (strcmp(tipopergunta, "FIM") == 0){
          break; //saira do programa
          }
      }
    }
        else if (perguntasint[numerocorrespondentedapergunta].respostacorreta != respostadousuario){
          printf ("Resposta errada, voce perdeu!\n");
          break; //se estiver errado, saira do programa apos aparecer a mensagem acima

          if (strcmp(tipopergunta, "FIM") == 0){
            break; //saira do programa
          }

        }
    
          //em caso da pergunta ser do tipo float
          else if (strcmp(tipopergunta, "FLOAT") == 0){
         scanf ("%i", &numerocorrespondentedapergunta); //lendo numero da pergunta
          printf ("Pergunta: %s\n", perguntasfloat[numerocorrespondentedapergunta].question); //printando pergunta
          printf ("Alternativa 0: %.2f\n", perguntasfloat[numerocorrespondentedapergunta].options1);
          printf ("Alternativa 1: %.2f\n", perguntasfloat[numerocorrespondentedapergunta].options2);
          printf ("Alternativa 2: %.2f\n", perguntasfloat[numerocorrespondentedapergunta].options3);
          scanf ("%i", &respostadousuario); //aqui usuario digita sua resposta

              //verificando a resposta do usuario com a cadastrada (caso o usuario acerte)
              if (perguntasfloat[numerocorrespondentedapergunta].correctanswer == respostadousuario){
                printf ("Parabens, voce acertou!\n");

                if (strcmp(tipopergunta, "FIM") == 0){
                    break; //saira do programa
                    }
              }
                //caso o usuario erre
                  else if (perguntasfloat[numerocorrespondentedapergunta].correctanswer != respostadousuario){
                    printf ("Resposta errada, voce perdeu!\n");
                    break; //saira do programa aqui

                    if (strcmp(tipopergunta, "FIM") == 0){
                    break; //saira do programa
                    }

                  } 
          }
                    //quando digita fim
                    if (strcmp(tipopergunta, "FIM") == 0){
                    break; //saira do programa
                    }
               
  } while (1); //condicao que rege a linha 92 e tudo o que esta entre as linhas 100 e 183

  return 0;

}